#ifndef __INT_LED__
#define __INT_LED__

#include "main.h"

typedef struct
{
    GPIO_TypeDef *port;
    uint16_t pin;
} LED_Struct;

/**
 * @brief ��LED��
 *
 * @param led
 */
void Int_led_turn_on(LED_Struct *led);

/**
 * @brief �ر�LED��
 * 
 * @param led 
 */
void Int_led_turn_off(LED_Struct *led);

/**
 * @brief ��תLED��
 * 
 * @param led 
 */
void Int_led_toggle(LED_Struct *led);

#endif // __INT_LED__
