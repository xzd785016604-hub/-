# P01_flight_hal RT-Thread migration notes

本包已经把应用层从 FreeRTOS API 迁移到 RT-Thread 风格 API：

- `App_freeRTOS_Task.c/.h` 已替换为 `App_rtt_Task.c/.h`
- `xTaskCreate` -> `rt_thread_create` + `rt_thread_startup`
- `vTaskDelay / vTaskDelayUntil` -> `rt_thread_mdelay / rt_thread_delay`
- `xTaskGetTickCount` -> `rt_tick_get`
- `xTaskNotifyGive / ulTaskNotifyTake` -> `rt_sem_release / rt_sem_take`
- `SysTick_Handler` 改为 `rt_tick_increase()` 接入
- Keil MDK 工程已移除 `freeRTOS` 组和 include 路径

## 重要说明

当前运行环境不能联网下载 RT-Thread 官方完整源码，也不能打开 Keil 进行实测编译。为了让 MDK 工程结构完整，我在：

```text
MDK-ARM/rtthread_compat/
```

放了一个最小 RT-Thread API 兼容层，主要用于让工程能先通过源码引用检查和编译入口迁移。它不是官方完整 RT-Thread 标准版内核，不能替代真正的抢占式调度器。

如果要上机飞行，请把官方 RT-Thread 标准版源码加入工程，至少需要：

```text
rt-thread/include
rt-thread/src
rt-thread/libcpu/arm/cortex-m3
```

然后保留本工程已经迁移好的应用层文件：

```text
MDK-ARM/Application/App_rtt_Task.c
MDK-ARM/Application/App_rtt_Task.h
Core/Src/stm32f1xx_it.c
Core/Src/main.c
```

并在 Keil 里把 `rtthread_compat` 组替换为官方 kernel/libcpu 文件。

## 建议首次编译检查

1. 用 Keil 打开：

```text
MDK-ARM/P01_flight_hal.uvprojx
```

2. 先 Clean，再 Rebuild。
3. 如果出现 RT-Thread 官方源码重复定义，删除 `RT-Thread/Compat` 组即可。
4. 如果出现 Flash/RAM 超限，先关闭 FinSH、DFS、网络、设备框架等组件。
